#!/bin/bash
# ══════════════════════════════════════════════════════════════════
#  LogicLand — One-command startup (Linux / macOS / Git Bash)
#  Usage: bash start_all.sh
# ══════════════════════════════════════════════════════════════════
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "╔═══════════════════════════════════════╗"
echo "║   🌿  LogicLand — Full Stack Start    ║"
echo "╚═══════════════════════════════════════╝"
echo ""

# ── Detect python ─────────────────────────────────────────────────
if command -v python3 &>/dev/null; then
  PYTHON=python3
elif command -v python &>/dev/null; then
  PYTHON=python
else
  echo "❌ Python not found. Install Python 3.10+ and retry."
  exit 1
fi

# ── Backend ───────────────────────────────────────────────────────
echo "🔧 Setting up Backend (FastAPI)..."
cd "$ROOT/backend"

if [ ! -d "venv" ]; then
  echo "   Creating virtual environment..."
  $PYTHON -m venv venv
fi

# Activate venv (works on Linux/macOS/Git Bash)
if [ -f "venv/Scripts/activate" ]; then
  source venv/Scripts/activate    # Git Bash on Windows
elif [ -f "venv/bin/activate" ]; then
  source venv/bin/activate        # Linux / macOS
fi

echo "   Installing Python packages..."
pip install -q -r requirements.txt

echo "   Seeding Neon DB..."
$PYTHON seed.py 2>/dev/null || echo "   (seed skipped — already exists)"

echo "   Starting backend on port 8000..."
uvicorn main:app --reload --host 0.0.0.0 --port 8000 &
BACKEND_PID=$!
echo "   ✅ Backend PID: $BACKEND_PID"

# ── Frontend ──────────────────────────────────────────────────────
echo ""
echo "🎨 Setting up Frontend (Next.js)..."
cd "$ROOT/frontend"

if ! command -v node &>/dev/null; then
  echo "❌ Node.js not found. Install Node.js 18+ and retry."
  kill $BACKEND_PID 2>/dev/null
  exit 1
fi

if [ ! -d "node_modules" ]; then
  echo "   Installing npm packages (first run — may take ~60s)..."
  npm install --silent
fi

echo "   Starting frontend on port 3000..."
npm run dev &
FRONTEND_PID=$!

echo ""
echo "╔═══════════════════════════════════════════════════╗"
echo "║  ✅ LogicLand is running!                         ║"
echo "║                                                   ║"
echo "║  🌐 App      → http://localhost:3000              ║"
echo "║  📖 API Docs → http://localhost:8000/docs         ║"
echo "║                                                   ║"
echo "║  🎮 Demo login:                                   ║"
echo "║     email:    demo@logicland.io                   ║"
echo "║     password: Demo1234!                           ║"
echo "║                                                   ║"
echo "║  Press Ctrl+C to stop both servers                ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""

trap "echo ''; echo 'Stopping servers...'; kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; exit 0" INT TERM
wait $BACKEND_PID $FRONTEND_PID
