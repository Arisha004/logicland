@echo off
REM ══════════════════════════════════════════════════════════════════
REM  LogicLand — One-command startup (Windows)
REM  Usage: Double-click  OR  run from CMD
REM ══════════════════════════════════════════════════════════════════

echo.
echo  ╔═══════════════════════════════════════╗
echo  ║   LogicLand — Full Stack Start        ║
echo  ╚═══════════════════════════════════════╝
echo.

SET ROOT=%~dp0

REM ── Detect python ────────────────────────────────────────────────
SET PYTHON=
where python >nul 2>&1
IF %ERRORLEVEL% EQU 0 (
    python -c "import sys; exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
    IF %ERRORLEVEL% EQU 0 SET PYTHON=python
)
IF "%PYTHON%"=="" (
    where python3 >nul 2>&1
    IF %ERRORLEVEL% EQU 0 SET PYTHON=python3
)
IF "%PYTHON%"=="" (
    echo  ERROR: Python 3.10+ not found.
    echo  Install from https://www.python.org — check "Add Python to PATH"
    pause & exit /b 1
)

REM ── Check Node ───────────────────────────────────────────────────
where node >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo  ERROR: Node.js not found. Install from https://nodejs.org
    pause & exit /b 1
)

REM ══════════════════════════════════════════
REM  BACKEND SETUP
REM ══════════════════════════════════════════
echo [1/2] Setting up Backend (FastAPI)...
cd /d "%ROOT%backend"

IF NOT EXIST "venv\" (
    echo    Creating virtual environment...
    %PYTHON% -m venv venv
)

call venv\Scripts\activate.bat

echo    Upgrading pip...
python -m pip install --upgrade pip --quiet

echo    Installing psycopg2-binary (pre-built wheel)...
pip install --only-binary :all: psycopg2-binary==2.9.10 --quiet
IF %ERRORLEVEL% NEQ 0 (
    pip install --only-binary :all: psycopg2-binary --quiet
)

echo    Installing remaining packages...
pip install -r requirements.txt --quiet
IF %ERRORLEVEL% NEQ 0 (
    echo    ERROR: pip install failed.
    pause & exit /b 1
)

echo    Seeding database...
python seed.py 2>nul || echo    (seed skipped — already exists)

echo    Starting backend on port 8000...
start "LogicLand Backend" cmd /k "cd /d %ROOT%backend && call venv\Scripts\activate.bat && python -m uvicorn main:app --reload --host 0.0.0.0 --port 8000"
echo    Backend window opened.

REM ══════════════════════════════════════════
REM  FRONTEND SETUP
REM ══════════════════════════════════════════
echo.
echo [2/2] Setting up Frontend (Next.js)...
cd /d "%ROOT%frontend"

IF NOT EXIST "node_modules\" (
    echo    Installing npm packages (first run ~60s)...
    npm install
)

echo    Starting frontend on port 3000...
start "LogicLand Frontend" cmd /k "cd /d %ROOT%frontend && npm run dev"

echo.
echo  ╔═══════════════════════════════════════════════════╗
echo  ║  LogicLand is running!                            ║
echo  ║                                                   ║
echo  ║  App      =^> http://localhost:3000               ║
echo  ║  API Docs =^> http://localhost:8000/docs          ║
echo  ║                                                   ║
echo  ║  Demo login:                                      ║
echo  ║    email:    demo@logicland.io                    ║
echo  ║    password: Demo1234!                            ║
echo  ║                                                   ║
echo  ║  Close the two terminal windows to stop servers   ║
echo  ╚═══════════════════════════════════════════════════╝
echo.
pause
